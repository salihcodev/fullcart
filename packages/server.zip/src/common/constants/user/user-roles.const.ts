const userRoles = {
    SUPPLER: "SUPPLER",
    CUSTOMER: "CUSTOMER",
    ADMIN: "ADMIN",
};

export default userRoles;
