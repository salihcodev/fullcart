// pkgs:

// utils:
import { VFC } from 'react';
import './style.sass';

// comps:

// component>>>
const dddddddddddd: VFC<any> = () => {
  return <section className="hhhhh"></section>;
};

export default dddddddddddd;
