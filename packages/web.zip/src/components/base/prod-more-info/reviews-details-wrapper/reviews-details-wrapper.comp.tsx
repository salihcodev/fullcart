// pkgs:

// utils:
import './style.sass';

// comps:

// component>>>
const ReviewsDetailsWrapper: React.VFC<{}> = () => {
  return (
    <section className="reviews-details-wrapper">
      <h4 className="heading">Product Reviews</h4>
    </section>
  );
};

export default ReviewsDetailsWrapper;
