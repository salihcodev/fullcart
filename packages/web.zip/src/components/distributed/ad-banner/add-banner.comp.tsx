// pkgs:

// utils:
import './style.sass';
import { IAddBanner } from '../../../common/interfaces/add-banner.interface';

// comps:

const AddBanner: React.VFC<IAddBanner> = () => {
  return (
    // xcvdssdg35456df4 to not be detectable by the browser extensions
    <section className="xcvdssdg35456df4">
      <div className="xcvdssdg35456df4-wrapper">
        <h2>xcvdssdg35456df4</h2>
      </div>
    </section>
  );
};

export default AddBanner;
