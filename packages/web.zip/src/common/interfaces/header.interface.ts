export interface IHeader {
  view: `expanded` | `minimal` | `company`;
  supplerView?: boolean;
}
