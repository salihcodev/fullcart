import { AuthedUser } from '../@types/auth.type';

export interface IUserAvatar {
  user: AuthedUser;
}
