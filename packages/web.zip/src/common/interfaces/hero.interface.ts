export interface IHero {}
