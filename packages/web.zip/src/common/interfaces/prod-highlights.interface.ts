import { ProdTypes } from '../@types/prod.types';

export interface IProdHighlights {
  prod: ProdTypes | null;
}
