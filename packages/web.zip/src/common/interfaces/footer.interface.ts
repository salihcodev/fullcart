export interface IFooter {
  view: `expanded` | `minimal` | `company`;
  supplerView?: boolean;
}
