export interface ICheckoutCalculations {
  calcs: { total: number; subTotal: number; delivery: number };
}
