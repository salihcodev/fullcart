export interface ISystemStatsInChart {}
