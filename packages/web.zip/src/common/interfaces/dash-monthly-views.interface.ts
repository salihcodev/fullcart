export interface IDashMonthlyViews {}
