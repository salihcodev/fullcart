export interface ILayout {
  view: `expanded` | `minimal` | `company`;
  children?: JSX.Element;
}
