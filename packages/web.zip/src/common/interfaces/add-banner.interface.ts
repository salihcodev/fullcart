export interface IAddBanner {}
