export interface IDashOnTheFlyInfo {
  heading: string;
  list: Array<[]>;
}
