export interface IUserCompleteCheckout {
  user: any;
}
