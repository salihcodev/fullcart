export interface IMonthlyViewCard {
  title: string;
  viewNumber: number;
}
