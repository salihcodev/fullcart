export interface IProdSmartCard {
  prodName: string;
  prodCover: string;
  height?: string;
  forCart?: boolean;
}
