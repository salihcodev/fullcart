export interface IDashEntitiesRow {
  heading: string;
  entities: Array<[]>;
}
