export interface IEntitiesBasicStats {}
