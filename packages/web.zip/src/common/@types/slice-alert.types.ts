export type SliceAlertTypes = {
  isAlertOpened: boolean;
};
