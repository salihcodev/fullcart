declare module 'react-world-flags' {
  const noTypesYet: any;
  export default noTypesYet;
}

// countries
// https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3
