export type ContactInFormTypes = {
  name: null | string;
  toMail: null | string;
  message: null | string;
};
