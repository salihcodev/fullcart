export type NewsletterSubscriptionTypes = {
  name: null | string;
  toMail: null | string;
  message: null | string;
};
