export type LoadStateTypes = `idle` | `busy` | `rejected`;
