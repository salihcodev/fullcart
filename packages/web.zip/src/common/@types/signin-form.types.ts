export type SignInFormTypes = {
  email: null | string;
  password: null | string;
};
