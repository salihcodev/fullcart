export type ContactSupplerFormTypes = {
  quantity: any;
  name: null | string;
  toMail: null | string;
  message: null | string;
};
