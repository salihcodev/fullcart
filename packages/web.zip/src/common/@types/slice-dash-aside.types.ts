export type SliceDashAsideTypes = {
  isAsideOpened: boolean;
};
