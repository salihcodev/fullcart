export type SignupFormTypes = {
  firstName: null | string;
  lastName: null | string;
  email: null | string;
  password: null | string;
  confirmPassword: null | string;
};
