const toFixedNumber = (num: any, limit: number = 2): number => Number(num?.toFixed(limit));

export default toFixedNumber;
