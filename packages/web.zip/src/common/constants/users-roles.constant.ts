const usersRoles = {
  ADMIN: `ADMIN`,
  SUPPLER: `SUPPLER`,
  CUSTOMER: `CUSTOMER`,
};

export default usersRoles;
